//@ JavaScript for Big War: The origin of the war
//@ Author - Mere Games or Rodion Kraynov
//@ Site - http://meregames.ru


/*## Data from data.js:
  gameConfig - 0:position, pre_position, endLoad, leng; 1:name, fullName, version;
  loadingGame - 0:loadMain; 1:loadMenu;
##*/
"use strict";

//Constants:
var TILE_SIZE = 64;
var NUM_MENU = 1, NUM_BUTTONS = 6;
var WIDTH = (TILE_SIZE*14), HEIGHT = (TILE_SIZE*8);

//Canvas
var canvas = document.getElementById("canvas"), ctx = canvas.getContext("2d");
canvas.width = WIDTH; canvas.height = HEIGHT;
//Main Global-Virabels
var musikPlay = true;
var musik = new Audio();
musik.src = "audio/ms_1.mp3";
musik.loop = true;
musik.play();

//Menu Images in menuImages
//Buttons Images in buttonImages
//Other Images in otherImages

//Menu
for(let num = 0; num < NUM_MENU; num++) {
	let img = new Image();
	img.src="img/menu_" + num + ".png";
    menuImages.push(img);
}

//Buttons
for(let num = 0; num < NUM_BUTTONS; num++) {
	let img = new Image();
	img.src = "img/but_" + num + ".png";
	buttonImages.push(img);
}
//All buttons
var objButtons = [
    //Company - 0
    new button("company", WIDTH/2 - 60, HEIGHT/2 - 100, WIDTH/2 - 60, HEIGHT/2 - 73, 160, 40, "Company", "30px Arial", "levels_1", "position", "menu", buttonImages[0], false),
    //Settings - 1
    new button("settings", WIDTH/2 - 60, HEIGHT/2 + 20, WIDTH/2 - 55, HEIGHT/2 + 50, 160, 40, "Settings", "30px Arial", "settings", "pre_position", "menu", buttonImages[0], false),
    //Free game - 2
    new button("freeGame", WIDTH/2 - 60, HEIGHT/2 - 40, WIDTH/2 - 57, HEIGHT/2 - 13, 160, 40, "Free game", "30px Arial", "game_free", "position", "menu", buttonImages[0], false),
    //Author - 3
    new button("author", WIDTH/2 - 60, HEIGHT/2 + 80, WIDTH/2 - 57, HEIGHT/2 + 108, 160, 40, "Author", "30px Arial", "author", "pre_position", "menu", buttonImages[0], false),

    //Cross for pre_pos - 4
    new button("cross", 617, 100, WIDTH/2 - 57, HEIGHT/2 + 108, 40, 40, "", "30px Arial", "none", "pre_position", "menu", buttonImages[1], false),
    //Left leng - 5
    new button("leftLeng", 280, 180, WIDTH/2 - 57, HEIGHT/2 + 108, 60, 40, "", "30px Arial", "en", "leng", "menu", buttonImages[2], false),
    //Right leng - 6
    new button("rightLeng", 560, 180, WIDTH/2 - 57, HEIGHT/2 + 108, 60, 40, "", "30px Arial", "ru", "leng", "menu", buttonImages[3], false),

    //Off and On - 7
    new button("on", 400, 295, WIDTH/2 - 57, HEIGHT/2 + 108, 40, 40, "", "30px Arial", "on", "mus", "menu", buttonImages[4], false),
    // off - 8
    new button("off", 450, 295, WIDTH/2 - 57, HEIGHT/2 + 108, 40, 40, "", "30px Arial", "off", "mus", "menu", buttonImages[5], false)
];

//img pre_posiiotns
var pre_pos = new Image();
pre_pos.src = "img/pre_0.png";
otherImages.push(pre_pos);


//Start Game func
function startGame() {
	//Begin
	loadingGame[0].loadMain = true;
	loadingGame[1].loadMenu = true;

	gameConfig[0].position == "menu";
}

//Logo
function logoGame() {
	var logo = new Image();
	logo.src = "logo.png";

	var iterLogo = setInterval(function () {
		ctx.drawImage(logo, 0, 0, WIDTH, HEIGHT);
	}, 1000/60);

	setTimeout(function (){
		clearInterval(iterLogo);
		ctx.clearRect(0, 0, WIDTH, HEIGHT);

		(loadingGame[0].loadMain == true) ? gameConfig[0].position = "menu" : gameConfig[0].position = "loading";
	}, 1300);
}

//loop game
function loop() {
	if(gameConfig[0].position == "menu" || gameConfig[0].position == "logo" || gameConfig[0].position == "loading") {
	    updateMenu();
	    drawMenu();

	    requestAnimationFrame(loop, canvas);
    }else {
    	ctx.clearRect(0, 0, WIDTH, HEIGHT);
    	document.body.style.cursor = "default";
    	console.log("-----------------------------\nEnd Menu\n-----------------------------");
    }
}

//Update menu
function updateMenu() {
	if(gameConfig[0].position != "logo") {

		//Clear All
		ctx.clearRect(0, 0, WIDTH, HEIGHT);

		if(gameConfig[0].pre_position == "none") {
			document.body.style.cursor = "default";
		    for(let t = 0; t < objButtons.length; t++) {
		            if(objButtons[t].over == true) {
			            document.body.style.cursor = "pointer";
			            return;
		            }else {
			            document.body.style.cursor = "default";
		           }
	        }
	    }else {
	    	document.body.style.cursor = "default";
		    for(let t = 0; t < objButtons.length; t++) {
			// --------------------------------------------------------------
			    if(objButtons[t].name == "cross" || objButtons[t].name == "leftLeng" || objButtons[t].name == "rightLeng" || objButtons[t].name == "on" || objButtons[t].name == "off") {
		            if(objButtons[t].over == true) {
			            document.body.style.cursor = "pointer";
			            return;
		            }else {
			            document.body.style.cursor = "default";
		            }
		    }
	    }
	}

		//Check loading
		// -----------------------------------------------------------------------
		if(loadingGame[1].loadMenu == false || loadingGame[0].loadMain == false) {
		    gameConfig[0].position = "loading";
	    }

	}
}

//Draw menu
function drawMenu() {
	if(gameConfig[0].position != "logo") {

		// ====Menu====
	    if(gameConfig[0].position == "menu") {
		    ctx.drawImage(menuImages[0], 0, 0, WIDTH, HEIGHT);

		    objButtons[0].draw();
		    objButtons[1].draw();
		    objButtons[2].draw();
		    objButtons[3].draw();

		    ctx.font = "80px cursive";
		    ctx.fillStyle = "Red";
		    ctx.fillText("Big War I", WIDTH/2 - 180, 90);
	    }

	    if(gameConfig[0].pre_position != "none") {
	    	ctx.save();
	    	ctx.globalAlpha = 0.5;
	    	ctx.fillStyle = "#000";
	    	ctx.fillRect(0, 0, WIDTH, HEIGHT);
	    	ctx.restore();
	    	ctx.drawImage(otherImages[0], WIDTH/2-200, HEIGHT/2-150, 400, 300);
	    	objButtons[4].draw();

	    	if(gameConfig[0].pre_position == "settings") {
	    		ctx.save();
	    		ctx.font = "30px strong";
	    		ctx.fillStyle = "#BA7A04";
	    		if(gameConfig[0].leng == "en") {
	    		    ctx.fillText("Language", 390, 170);
	    		    ctx.fillText("Music", 410, 280);

	    		    ctx.save();
	    		    ctx.font = "30px cursive";
	    		    if(musikPlay == true) {
	    		        ctx.fillText("On", 427, 365);
	    		    }else {
	    		    	ctx.fillText("Off", 419, 365);
	    		    }
	    		    ctx.restore();
	    	    }else if(gameConfig[0].leng == "ru") {
	    	    	ctx.fillText("Язык", 420, 170);
	    	    	ctx.fillText("Музыка", 400, 280);

	    	    	ctx.save();
	    		    ctx.font = "30px cursive";
	    		    if(musikPlay == true) {
	    		        ctx.fillText("Вкл.", 419, 365);
	    		    }else {
	    		    	ctx.fillText("Выкл.", 417, 365);
	    		    }
	    		    ctx.restore();
	    	    }
	    		ctx.font = "30px cursive";
	    		if(gameConfig[0].leng == "en") {
	    			ctx.fillText("English", 395, 210);
	    		}else if(gameConfig[0].leng == "ru") {
	    			ctx.fillText("Русский", 395, 210);
	    		}
	    		ctx.restore();
	    		objButtons[5].draw();
	    		objButtons[6].draw();
	    		if(musikPlay == true) {
	    			objButtons[7].x = 587;
	    			objButtons[8].x = 427;
	    			objButtons[8].draw();
	    	    }else if(musikPlay == false){
	    	    	objButtons[7].x = 427;
	    			objButtons[8].x = 590;
	    			objButtons[7].draw();
	    	    }
	    	}else if(gameConfig[0].pre_position == "author") {
	    		if(gameConfig[0].leng == "en") {
	    			ctx.save();
	    			ctx.fillStyle = "#BA7A04";
	    			ctx.font = "30px Arial";
	    			ctx.fillText("Mere Games", WIDTH/2 - 80, 150);
	    			ctx.font = "17px Arial";
	    			ctx.fillText("Copyright 2016", WIDTH/2 - 50, 380);
	    			ctx.font = "20px Arial";
	    			ctx.fillText("Official site:", WIDTH/2 - 40, 180);
	    			ctx.fillText('http://meregames.ru', WIDTH/2 - 80, 210);
	    			ctx.fillText("Developer:", WIDTH/2 - 40, 250);
	    			ctx.fillText('Rodion Kraynov', WIDTH/2 - 70, 280);
	    			ctx.restore();
	    		}else if(gameConfig[0].leng == "ru") {
	    			ctx.save();
	    			ctx.fillStyle = "#BA7A04";
	    			ctx.font = "30px Arial";
	    			ctx.fillText("Mere Games", WIDTH/2 - 80, 150);
	    			ctx.font = "17px Arial";
	    			ctx.fillText("Copyright 2016", WIDTH/2 - 50, 380);
	    			ctx.font = "20px Arial";
	    			ctx.fillText("Официальный сайт:", WIDTH/2 - 80, 180);
	    			ctx.fillText('http://meregames.ru', WIDTH/2 - 80, 210);
	    			ctx.fillText("Разработчик:", WIDTH/2 - 55, 250);
	    			ctx.fillText('Родион Крайнов', WIDTH/2 - 70, 280);
	    			ctx.restore();
	    		}
	    	}
	    }

	    // ====Loading=====
	    if(gameConfig[0].position == "loading") {
		    //-----------------------------------------------------------------------
		        ctx.font = "70px cursive";
		        ctx.fillStyle = "#fff";
		        ctx.drawImage(menuImages[0], 0, 0, WIDTH, HEIGHT);
		        ctx.fillText("Loading...", WIDTH/2 - 140, HEIGHT/2);
		        document.body.style.cursor = "default";
	    }

	    //====*Version
	    if(gameConfig[0].position == "menu") {
	        ctx.font = "13px Arial";
	        ctx.fillStyle = "#fff";
	        ctx.fillText(gameConfig[1].version, WIDTH - 32, HEIGHT - 5);
	    }

    }
}

//Load locations
function loadLocation() {
	gameConfig[0].position = "loading";
	setTimeout(function () {
		gameConfig[0].position = gameConfig[0].endLoad;
	}, 2000);
}

//Lenguege
function lengGame(leng) {
	if(leng == "ru") {
		gameConfig[0].leng = "ru";
		//buttons
		for(let i = 0; i < objButtons.length; i++) {
			if(objButtons[i].name == tranTexts[0].ru[i].name) {
				objButtons[i].text = tranTexts[0].ru[i].tran;
				//---------------------======--------------
				if(objButtons[i].name == "freeGame") {
					objButtons[i].font = "20px Arial";
				}
			}
		}
	}else if(leng == "en") {
		gameConfig[0].leng = "en";
		//buttons
		for(let i = 0; i < objButtons.length; i++) {
			if(objButtons[i].name == tranTexts[1].en[i].name) {
				objButtons[i].text = tranTexts[1].en[i].tran;
				// -------------------========--------------
				if(objButtons[i].name == "freeGame") {
					objButtons[i].font = "30px Arial";
				}
			}
		}
	}
}

//Music off and on
function musikOnOff(type) {
	if(type == "off") {
		musik.pause();
		musikPlay = false;;
	}else {
		musik.play();
		musikPlay = true;
	}
}

logoGame();
//Events
//Moves
function moveEvent(e) {
	let x = e.clientX;
	let y = e.clientY;

	if(gameConfig[0].position != "logo" && gameConfig[0].pre_position == "none") {
		if(gameConfig[0].position == "menu") {
			for(let i = 0; i < objButtons.length; i++) {
				if(checkPosMouse(x, y, objButtons[i].x, objButtons[i].y, objButtons[i].width, objButtons[i].height) && objButtons[i].text != "") {
					objButtons[i].over = true;
				}else {
					objButtons[i].over = false;
				}
			}
		}
	}else {
		for(let i = 0; i < objButtons.length; i++) {
			// ---------------------------------------------
			if(objButtons[i].name == "cross" || objButtons[i].name == "leftLeng" || objButtons[i].name == "rightLeng") {
				if(checkPosMouse(x, y, objButtons[i].x, objButtons[i].y, objButtons[i].width, objButtons[i].height)) {
					if(gameConfig[0].pre_position == "settings") {
						if(objButtons[i].name == "cross" || objButtons[i].name == "leftLeng" || objButtons[i].name == "rightLeng" || objButtons[i].name == "on" || objButtons[i].name == "off") {
					    objButtons[i].over = true;
				    }
				}else if(gameConfig[0].pre_position == "author") {
						if(objButtons[i].name == "cross") {
					    objButtons[i].over = true;
				    }
			}
			}else {
					  objButtons[i].over = false;
				  }
		}
		}
	}
}

//Clicks
function clickEvent(e) {
	let x = e.clientX;
	let y = e.clientY;

	if(gameConfig[0].position != "logo" && gameConfig[0].pre_position == "none") {
		if(gameConfig[0].position == "menu") {
			for(let i = 0; i < objButtons.length; i++) {
				if(checkPosMouse(x, y, objButtons[i].x, objButtons[i].y, objButtons[i].width, objButtons[i].height)) {
					objButtons[i].activ();
				}
			}
		}
	}else {
		for(let i = 0; i < objButtons.length; i++) {
			// -------------------------------------------------
				if(checkPosMouse(x, y, objButtons[i].x, objButtons[i].y, objButtons[i].width, objButtons[i].height)) {
					if(gameConfig[0].pre_position == "settings") {
						if(objButtons[i].name == "cross" || objButtons[i].name == "leftLeng" || objButtons[i].name == "rightLeng" || objButtons[i].name == "on" || objButtons[i].name == "off") {
					        objButtons[i].activ();
					    }
				    }else if(gameConfig[0].pre_position == "author") {
				    	if(objButtons[i].name == "cross") {
					        objButtons[i].activ();
					    }
				    }
				}
		}
	}
}

function checkPosMouse(x, y, xo, yo, width, height) {
	if(x >= xo && x <= xo + width && y >= yo && y <= yo + height) {
		return true;
	}else {
		return false;
	}
}

if(gameConfig[0].position == "menu" || gameConfig[0].position == "logo") {
    canvas.onmousemove = moveEvent;
    canvas.onclick = clickEvent;
}
requestAnimationFrame(loop, canvas);
window.onload = startGame;

window.onerror = function () {
	gameConfig[0].pre_position = "error";
	alert("error");
}