//@ key_codes.js for Big War: The origin of the war
//@ Author - Mere Games or Rodion Kraynov
//@ Site - http://meregames.ru

var keyCodes = [
    {name: "Esc", code: 27},
    {name: "0", code: 48},
    {name: "1", code: 49},
    {name: "2", code: 50},
    {name: "3", code: 51},
    {name: "4", code: 52},
    {name: "5", code: 53},
    {name: "6", code: 54},
    {name: "7", code: 55},
    {name: "8", code: 56},
    {name: "9", code: 57},
    {name: "Ctrl", code: 17}
];

