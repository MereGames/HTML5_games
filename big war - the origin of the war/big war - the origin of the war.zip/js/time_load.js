//@ time_load.js for Big War: The origin of the war
//@ Author - Mere Games or Rodion Kraynov
//@ Site - http://meregames.ru


//Mini-time for loading game locations(for all)
var timesLoad = [
    {name: "butCon", time: 500},
    {name: "befoLogo", time: 1500},
    {name: "inLevel", time: 1000}
];
