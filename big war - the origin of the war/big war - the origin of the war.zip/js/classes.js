//@ Classes for Big War: The origin of the war


//Class button
var button = function (name, x, y, xt, yt, width, height, text, font, action, typeAction, type, img, over) {
	this.x = x;
	this.y = y;
	this.xt = xt;
	this.yt = yt;
	this.width = width;
	this.height = height;
	this.img = img;
	this.imgOver = img;
	this.font = font;
	this.over = over;
	this.name = name;

	this.text = text;
	this.action = action;
	this.typeAction = typeAction;
	this.type = type;


	this.draw = function () {
		if(this.type == "menu") {
			(this.over == true || this.over == 'true') ? ctx.globalAlpha = 0.5 : ctx.globalAlpha = 1;
			if(this.over == false) {
			    ctx.drawImage(this.img, this.x, this.y, this.width, this.height);
		    }else {
		    	ctx.drawImage(this.imgOver, this.x, this.y, this.width, this.height);
		    }
			ctx.font = this.font;
			ctx.fillText(this.text, this.xt, this.yt);
			ctx.globalAlpha = 1;
		}
	}
	this.activ = function () {
		if(this.typeAction == "position") {
			gameConfig[0].endLoad = this.action;
			loadLocation();
		}else if(this.typeAction == "pre_position") {
			gameConfig[0].pre_position = this.action;
		}else if(this.typeAction == "leng"  && gameConfig[0].pre_position != "none") {
			lengGame(action);
		}else if(this.typeAction == "mus"  && gameConfig[0].pre_position != "none") {
			musikOnOff(action);
			return;
		}
	}
}