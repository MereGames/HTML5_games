//@ maps.js for Big War: The origin of the war
//@ Author - Mere Games or Rodion Kraynov
//@ Site - http://meregames.ru


var mapsGame = [];

var levelsMaps = [

    {level: 0, map: []},

    {level: 1, map: []},

    {level: 2, map: []},

    {level: 3, map: []},

    {level: 4, map: []},

    {level: 5, map: []},

    {level: 6, map: []},

    {level: 7, map: []},

    {level: 8, map: []},

    {level: 9, map: []},

    {level: 10, map: []},

    {level: 11, map: []},

    {level: 12, map: []}

];
